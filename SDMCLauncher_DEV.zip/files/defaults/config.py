# Modules for config parts
import os

# Configuration file for the launcher. be free to modify it.
# just don't download random configs off the internet as they can harm your device.

# Dual Config Feature. Will allow you to select a config when starting launcher.
DUAL_CONFIG = False
DUAL_CONFIG_PATH = "data/dual_config"

# Placeholders for when something is not found.
MCJAVA_PLACEHOLDERS = {
    "username": "undefined",
    "signintype": "-1"
}

# Microsoft Login
#Disabled as i cannot pay for azure app registration. but you can make ur own and enable and set CLIENT_ID and REDIRECT_URL
ENABLE_MICROSOFT_LOGIN = False
#CLIENT_ID = "00000000402b5328"
#REDIRECT_URL = "https://login.microsoftonline.com/common/oauth2/nativeclient"

# Cracked Login
ENABLE_CRACKED_LOGIN = True

# Directories
TMP_DIR = "tmp"
DATA_DIR = "data"
INSTALL_DIR = "install"

# Minecraft Java And Bedrock Installation Directories
INSTALL_DIR_MCJAVA = os.path.join(INSTALL_DIR, "minecraft", "java")
INSTALL_DIR_MCBEDROCK = os.path.join(INSTALL_DIR, "minecraft", "bedrock")

# External Installation Directories
INSTALL_DIR_EXTERNAL = os.path.join(INSTALL_DIR, "external")

# Configuration for JDK
JDK_INSTALL_DIR = os.path.join(INSTALL_DIR_EXTERNAL, "JDK")
JDK_DOWNLOAD_URL = "https://download.oracle.com/java/21/archive/jdk-21.0.4_windows-x64_bin.zip"
JDK_EXE_PATH = os.path.join(JDK_INSTALL_DIR, "jdk-21.0.4", "bin", "java.exe")

# Minecraft Java Configuration
GAME_DIR_MCJAVA = os.path.join(DATA_DIR, "java", "game")
ENABLE_MCJAVA_INSTANCES = True
ALLOW_SETTINGS_MODIFY_JAVA = True
MCJAVA_INSTANCE_DIR = os.path.join("instances", "java")