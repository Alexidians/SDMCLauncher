print("Importing Modules...")
import sys
import os
import subprocess
import shutil
import zipfile
import json
import hashlib
try:
    import minecraft_launcher_lib
except ImportError as e:
    if not getattr(sys, 'frozen', False):
        subprocess.check_call([sys.executable, "-m", "pip", "install", "minecraft_launcher_lib"])
        import requests
    else:
        print("!ERROR! minecraft-launcher-lib is not installed. and this is a frozen application. so it can not be automatically installed.")

try:
    import mcstatus
except ImportError as e:
    if not getattr(sys, 'frozen', False):
        subprocess.check_call([sys.executable, "-m", "pip", "install", "mcstatus"])
        import requests
    else:
        print("!ERROR! mcstatus is not installed. and this is a frozen application. so it can not be automatically installed.")

try:
    import requests
except ImportError as e:
    if not getattr(sys, 'frozen', False):
        subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
        import requests
    else:
        print("!ERROR! requests is not installed. and this is a frozen application. so it can not be automatically installed.")
        

try:
    from tqdm import tqdm
except ImportError as e:
    if not getattr(sys, 'frozen', False):
        subprocess.check_call([sys.executable, "-m", "pip", "install", "tqdm"])
        from tqdm import tqdm
    else:
        print("!ERROR! tqdm is not installed. and this is a frozen application. so it can not be automatically installed.")

try:
    import tkinter as tk
except ImportError as e:
    if not getattr(sys, 'frozen', False):
        subprocess.check_call([sys.executable, "-m", "pip", "install", "tqdm"])
        import tkinter as tk
    else:
        print("!ERROR! tkinter is not installed. and this is a frozen application. so it can not be automatically installed.")

def md5_string(input_string):
    # Create an MD5 hash object
    hash_object = hashlib.md5()
    # Update the hash object with the string, encoded to bytes
    hash_object.update(input_string.encode('utf-8'))
    # Get the hexadecimal representation of the hash
    return hash_object.hexdigest()

def start_dual_config_setup():
    print("First. lets start with setting a password. it can be nothing. if you like.")
    dualcfgmngpasswd = input("Enter Manager Password: ")
    passwordfilemng = open(os.path.join(DUAL_CONFIG_PATH, "mngpassword.txt"), "w")
    passwordfilemng.write(md5_string(dualcfgmngpasswd))
    passwordfilemng.close()
    print("Now. lets make your first config.")
    dualcfgname = input("Enter First Config Name: ")
    dualcfgpassword = input("Enter First Config Password (Empty for None): ")
    print("Now we will be making you your first dual config. Please wait.")
    cfgpath = os.path.join(DUAL_CONFIG_PATH, "configs", dualcfgname)
    os.makedirs(cfgpath, exist_ok=True)
    shutil.copytree("files/defaults/config.py", os.path.join(cfgpath, "config.py"))
    if dualcfgpassword != "":
        print("Password Protecting...")
        passwordfile = open(os.path.join(cfgpath, "password.txt"), "w")
        passwordfile.write(md5_string(dualcfgpassword))
        passwordfile.close()
        print("Password Protected")
    print("Your first config is ready now. You can change config.py at", os.path.abspath(cfgpath))
    print("Once you are done editing your config. you can restart the launcher and see it with Dual Config.")
    input("Press Enter To Exit")
    exit()

def manage_dual_configs():
    passwordfile = open(os.path.join(DUAL_CONFIG_PATH, "mngpassword.txt"), "r")
    passwordhash = passwordfile.read()
    passwordfile.close()
    while True:
        passwordinput = input("Enter Manager Password: ")
        if md5_string(passwordinput) == passwordhash:
            break
    while True:
        print("Options:")
        print("1.Create New Config")
        print("2.Delete Config")
        print("3.Modify Config")
        option = input("Enter Choice: ")
        if option == "1":
            manage_dual_configs_create()

def manage_dual_configs_create():
    dualcfgname = input("Enter Config Name: ")
    dualcfgpassword = input("Enter Config Password (Empty for None): ")
    print("Now we will be making you your dual config. Please wait.")
    cfgpath = os.path.join(DUAL_CONFIG_PATH, "configs", dualcfgname)
    os.makedirs(cfgpath, exist_ok=True)
    shutil.copytree("files/defaults/config.py", os.path.join(cfgpath, "config.py"))
    if dualcfgpassword != "":
        print("Password Protecting...")
        passwordfile = open(os.path.join(cfgpath, "password.txt"), "w")
        passwordfile.write(md5_string(dualcfgpassword))
        passwordfile.close()
        print("Password Protected")
    print("Config Has Been Created. You can change config.py at", os.path.abspath(cfgpath))

def manage_dual_configs_delete():
    configlist = os.listdir(os.path.join(DUAL_CONFIG_PATH, "configs"))
    for config in configlist:
        print(config)
    configname = input("Enter Config Name To Delete: ")
    configdir = os.path.join(DUAL_CONFIG_PATH, "configs", configname)
    if not os.path.exists(configdir):
        print("Config Not Found.")
        input("Press enter to exit")
        exit()
    if os.path.exists(os.path.join(configdir, "password.txt")):
        print("This config is password protected.")
        tries = 3
        passwordfile = open(os.path.join(configdir, "password.txt"), "r")
        passwordhash = passwordfile.read()
        passwordfile.close()
        while True:
            print(tries, "Tries Remaining")
            passwordinput = input("Enter Config Password: ")
            if md5_string(passwordinput) == passwordhash:
                print("Password Correct")
                os.makedirs(os.path.join(DUAL_CONFIG_PATH, "deleted_configs"), exist_ok=True)
                shutil.copytree(configdir, os.path.join(DUAL_CONFIG_PATH, "deleted_configs", configname))
                shutil.rmtree(configdir)
            else:
                print("Password Incorrect")
                tries = tries - 1
                if tries == 0:
                    print("Out of Tries")
                    break

def manage_dual_configs_modify():
    configlist = os.listdir(os.path.join(DUAL_CONFIG_PATH, "configs"))
    for config in configlist:
        print(config)
    configname = input("Enter Config Name To Modify: ")
    configdir = os.path.join(DUAL_CONFIG_PATH, "configs", configname)
    if not os.path.exists(configdir):
        print("Config Not Found.")
        return
    print("Modify config.py at", os.path.abspath(configdir))

print("Loading Config...")
if not os.path.exists("config.py"):
    print("Config not found. Using Default Instead.")
    shutil.copy2(os.path.join("files", "defaults", "config.py"), "config.py")
cfgfile = open("config.py", "r")
cfgdata = cfgfile.read()
cfgfile.close()
exec(cfgdata, globals())
if DUAL_CONFIG:
    print("Dual Config is enabled.")
    os.makedirs(os.path.join(DUAL_CONFIG_PATH, "configs"), exist_ok=True)
    configlist = os.listdir(os.path.join(DUAL_CONFIG_PATH, "configs"))
    if configlist == []:
        print("Dual Config Configs is empty.")
        StartDualCFGSetup = input("Would you like to start Dual Config Setup? (Y/N)")
        if StartDualCFGSetup.lower() == "y":
            startDualConfigSetup()
    for config in configlist:
        print(config)
    configname = input("Enter Config Name (Manage to enter manager): ")
    if configname == "Manage":
        manage_dual_configs()
    configdir = os.path.join(DUAL_CONFIG_PATH, "configs", configname)
    if not os.path.exists(configdir):
        print("Config Not Found.")
        input("Press enter to exit")
        exit()
    if os.path.exists(os.path.join(configdir, "password.txt")):
        print("This config is password protected.")
        tries = 3
        passwordfile = open(os.path.join(configdir, "password.txt"), "r")
        passwordhash = passwordfile.read()
        passwordfile.close()
        while True:
            print(tries, "Tries Remaining")
            passwordinput = input("Enter Config Password: ")
            if md5_string(passwordinput) == passwordhash:
                print("Password Correct")
                break
            else:
                print("Password Incorrect")
                tries = tries - 1
                if tries == 0:
                    print("Out of Tries")
                    input("Press enter to exit")
                    exit()
    print("Loading Config...")
    cfgfile = open(os.path.join(configdir, ""), "r")
    cfgdata = cfgfile.read()
    cfgfile.close()
            



print("Loading Login Data...")
if os.path.exists(os.path.join(DATA_DIR, "java", "login.json")):
    loginfile = open(os.path.join(DATA_DIR, "java", "login.json"), "r")
    logindata = json.loads(loginfile.read())
    loginfile.close()
    signintypejava = logindata["signintype"]
    usernamejava = logindata["username"]
else:
    print("Warning: No login data found. using placeholder.")
    signintypejava = MCJAVA_PLACEHOLDERS["signintype"]
    usernamejava = MCJAVA_PLACEHOLDERS["username"]

print("Making Directories...")
os.makedirs(TMP_DIR, exist_ok=True)
os.makedirs(INSTALL_DIR_MCJAVA, exist_ok=True)
os.makedirs(INSTALL_DIR_MCBEDROCK, exist_ok=True)
os.makedirs(INSTALL_DIR_EXTERNAL, exist_ok=True)
os.makedirs(os.path.join(DATA_DIR, "java"), exist_ok=True)
os.makedirs(os.path.join(DATA_DIR, "bedrock"), exist_ok=True)

print("Loading Setting Utils...")

# Function to update settings with default values
def update_settings(defaults, settings):
    for key, value in defaults.items():
        # If the key does not exist in settings, add it
        if key not in settings:
            settings[key] = value
        # If the value is a nested dictionary, recursively update
        elif isinstance(value, dict) and isinstance(settings.get(key), dict):
            update_settings(value, settings[key])

print("Loading Setting Utils java specific...")
def save_settings_java(restrict=True):
    global settings
    if restrict:
        if not ALLOW_SETTINGS_MODIFY_JAVA:
            print("ERROR: Failed to save settings. Modifying Settings for java is not Allowed.")
            print("Reverting Settings...")
            settingsfile = open(os.path.join(DATA_DIR, "java", "settings.json"), "r")
            settings = json.loads(settingsfile.read())
            settingsfile.close()
            print("Changes Reverted.")
            return
    settingsfile = open(os.path.join(DATA_DIR, "java", "settings.json"), "w")
    settingsfile.write(json.dumps(settings))
    settingsfile.close()

print("Loading OS Path Join Auto Normalizer...")
def cstmospathjoin(*args):
    return os.path.normpath(origospathjoin(*args))

origospathjoin = os.path.join
os.path.join = cstmospathjoin

print("Loading Java Version Array...")
if not os.path.exists(os.path.join(DATA_DIR, "java", "versionarray.json")):
    print("WARNING: Version array not found. please regenarate it to use the launcher.")
    varrayfile = open(os.path.join(DATA_DIR, "java", "versionarray.json"), "w")
    varrayfile.write(json.dumps([]))
    varrayfile.close()
    version_array = []
else:
    varrayfile = open(os.path.join(DATA_DIR, "java", "versionarray.json"), "r")
    version_array = json.loads(varrayfile.read())
    varrayfile.close()

print("Loading Java Settings...")
JAVA_SETTINGS_DEFAULT = {
    "demo": False,
    "memoryallocation": -1,
    "enablelog4jconfig": False,
    "enableMultiplayer": True,
    "enableChat": True
}
if not os.path.exists(os.path.join(DATA_DIR, "java", "settings.json")):
    settingsfile = open(os.path.join(DATA_DIR, "java", "settings.json"), "w")
    settingsfile.write(json.dumps(JAVA_SETTINGS_DEFAULT))
    settingsfile.close()
else:
    settingsfile = open(os.path.join(DATA_DIR, "java", "settings.json"), "r")
    settings = json.loads(settingsfile.read())
    update_settings(JAVA_SETTINGS_DEFAULT, settings)
    settingsfile.close()
    save_settings_java(restrict=False)

print("Loading Install Progress bar...")
current_max = 0


def set_status(status: str):
    print(status)


def set_progress(progress: int):
    if current_max != 0:
        print(f"{progress}/{current_max}")


def set_max(new_max: int):
    global current_max
    current_max = new_max


minecraft_directory = minecraft_launcher_lib.utils.get_minecraft_directory()

callback = {
    "setStatus": set_status,
    "setProgress": set_progress,
    "setMax": set_max
}


print("Loading Functions...")
def download_file(url, file_name):
    # Make the GET request to the URL and get the total content length
    with requests.get(url, stream=True) as r:
        r.raise_for_status()  # Raise an exception for HTTP errors
        total_size = int(r.headers.get('content-length', 0))  # Get the total size of the file

        # Use tqdm to show progress of the download
        with open(file_name, 'wb') as f:
            for chunk in tqdm(r.iter_content(chunk_size=1024), total=total_size // 1024, unit='KB', desc=f"Downloading {file_name}"):
                if chunk:  # filter out keep-alive new chunks
                    f.write(chunk)

def extract_zip(zip_file, extract_dir):
    # Open the zip file and get the list of files
    with zipfile.ZipFile(zip_file, 'r') as zip_ref:
        # Use tqdm to show progress of extraction
        with tqdm(total=len(zip_ref.infolist()), unit='file', desc=f"Extracting {zip_file}") as pbar:
            for file in zip_ref.infolist():
                zip_ref.extract(file, extract_dir)
                pbar.update(1)  # Update the progress bar for each extracted file

def generate_version_array_java():
    global version_array
    url = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
    
    # Fetch the version manifest
    response = requests.get(url)
    
    if response.status_code != 200:
        print("Failed to fetch the version manifest.")
        return []

    # Parse the JSON response
    manifest = response.json()

    # Extract the 'versions' array
    versions = manifest.get("versions", [])

    # Initialize the progress bar using tqdm
    version_array = []
    for version in tqdm(versions, desc="Processing versions", unit="version"):
        version_array.append(f"{version['type']}:{version['id']}")
    
    versionarrayfile = open(os.path.join(DATA_DIR, "java", "versionarray.json"), "w")
    versionarrayfile.write(json.dumps(version_array))
    versionarrayfile.close()
    return version_array

def install_jdk():
    if os.path.exists(JDK_INSTALL_DIR):
        shutil.rmtree(JDK_INSTALL_DIR)
    download_file(JDK_DOWNLOAD_URL, os.path.join(TMP_DIR, "jdk.zip"))
    extract_zip(os.path.join(TMP_DIR, "jdk.zip"), JDK_INSTALL_DIR)

def normalize_java_versions_array(versionarrayfromjava):
    normalized = []
    for versiondict in versionarrayfromjava:
        normalized.append(versiondict["type"] + ":" + versiondict["id"])
    return normalized

def select_with_search(options):
    def update_list(event=None):
        # Get the text from the search entry field
        search_query = search_var.get().lower()

        # Filter the options based on the search query
        filtered_options = [option for option in options if search_query in option.lower()]

        # Clear the current listbox
        listbox.delete(0, tk.END)

        # Insert the filtered options into the listbox
        for option in filtered_options:
            listbox.insert(tk.END, option)

    def on_select(event):
        # Get the selected option from the listbox
        selected_option = listbox.get(tk.ANCHOR)
        if selected_option:
            root.quit()  # Close the window
            result.set(selected_option)

    # Create the main window
    root = tk.Tk()
    root.title("Search and Select")

    # Create a StringVar to hold the search query
    search_var = tk.StringVar()

    # Create a search entry field
    search_entry = tk.Entry(root, textvariable=search_var, width=30)
    search_entry.pack(padx=10, pady=10)

    # Create a button to update the list based on the search query
    search_button = tk.Button(root, text="Search", command=update_list)
    search_button.pack(padx=10, pady=5)

    # Create a listbox to display filtered options
    listbox = tk.Listbox(root, height=10, width=40, selectmode=tk.SINGLE)
    listbox.pack(padx=10, pady=10)

    # Bind the Enter key to trigger the search
    search_entry.bind('<Return>', update_list)

    # Bind the listbox selection event
    listbox.bind('<<ListboxSelect>>', on_select)

    # Call the update_list function to show the initial options
    update_list()

    # Variable to hold the result
    result = tk.StringVar()

    # Start the Tkinter event loop
    root.mainloop()

    # Return the selected result
    return result.get()

def main():
    print("Options:")
    print("1. Reinstall JDK")
    print("2. Java Launcher")
    print("3. Bedrock Launcher")
    choice = input("Enter Option:")
    if choice == "1":
        install_jdk()
    elif choice == "2":
        java_launcher()
    elif choice == "3":
        bedrock_launcher()

def bedrock_launcher():
    print("Bedrock is not supported. but you can still use server list. but still. java > bedrock")
    while True:
        print("Options:")
        print("1. Server List")
        print("2. Back")
        choice = input("Enter Option:")
        if choice == "1":
            server_list_bedrock()
        elif choice == "0":
            main()
            break

def add_server_bedrock():
    srvfile = open(os.path.join(DATA_DIR, "bedrock", "servers.txt"), "a")
    srvfile.write(input("Enter Server IP:"))
    srvfile.close()

def remove_server_bedrock():
    srvfile = open(os.path.join(DATA_DIR, "bedrock", "servers.txt"), "r")
    servers = srvfile.read().split("\n")
    srvfile.close()
    for i, server in enumerate(servers):
        print(f"{i + 1}. {server}")
    choice = int(input("Enter Server Number to Remove:"))
    servers.pop(choice - 1)
    srvfile = open(os.path.join(DATA_DIR, "bedrock", "servers.txt"), "w")
    srvfile.write("\n".join(servers))
    srvfile.close()

def server_list_bedrock():
    while True:
        print("Options:")
        print("1. Add Server")
        print("2. Remove Server")
        print("3. List Servers")
        print("4. Back")
        choice = input("Enter Option:")
        if choice == "1":
            add_server_bedrock()
        elif choice == "2":
            remove_server_bedrock()
        elif choice == "3":
            srvfile = open(os.path.join(DATA_DIR, "bedrock", "servers.txt"), "r")
            servers = srvfile.read().split("\n")
            srvfile.close()
            for server in servers:
                if server != "":
                    mcsrv = mcstatus.BedrockServer.lookup(server)
                    try:
                        pingval = mcsrv.status().latency
                        print(f"{server} - {pingval}ms")
                    except Exception as e:
                        print(f"{server} -  Error: {e}")
        elif choice == "4":
            break

def java_launcher_instances():
    global version_array
    if not ENABLE_MCJAVA_INSTANCES:
        print("ERROR: Instances are disabled. enable them in the confing and try again.")
    while True:
        print("Options:")
        print("1. Select Instance")
        print("2. Create Instance")
        print("0. Back")
        choice = input("Enter Option:")
        if choice == "1":
            for instance in os.listdir(MCJAVA_INSTANCE_DIR):
               print(instance)
            instancename = input("Enter instance name to select: ")
            instancedir = os.path.join(MCJAVA_INSTANCE_DIR, instancename)
            if not os.path.exists(instancedir):
                print("Instance not found.")
                continue
            while True:
                print("Options:")
                print("1. Launch Instance")
                print("2. Change Version")
                print("3. Open Instance Folder")
                choice1 = input("Enter Option: ")
                if choice1 == "1":
                    versionfile = open(os.path.join(instancedir, "version.txt"), "r")
                    versionstr = versionfile.read()
                    versionfile.close()
                    start_mc_java_instance(versionstr.split(":")[1], os.path.join(instancedir, "gamedir"))
                elif choice1 == "2":
                    versionstr = select_with_search(normalize_java_versions_array(minecraft_launcher_lib.utils.get_installed_versions(INSTALL_DIR_MCJAVA)))
                    versionfile = open(os.path.join(instancedir, "version.txt"), "r")
                    versionfile.write(versionstr)
                    versionfile.close()
                elif choice1 == "3":
                    os.startfile(instancedir)

        elif choice == "2":
            instancename = input("Enter New Instance Name: ")
            instanceversion = select_with_search(normalize_java_versions_array(minecraft_launcher_lib.utils.get_installed_versions(INSTALL_DIR_MCJAVA)))
            create_java_instance(instancename, instanceversion)
        elif choice == "0":
            break

def start_mc_java_instance(mcver, gameDirectory):
    print("Starting Minecraft", mcver)
    options = generate_options_java()
    options["gameDirectory"] = os.path.abspath(gameDirectory)
    command =  minecraft_launcher_lib.command.get_minecraft_command(mcver, os.path.abspath(INSTALL_DIR_MCJAVA), options)
    subprocess.run(command, cwd=os.path.abspath(gameDirectory))

def create_java_instance(name, version):
    instancedir = os.path.join(MCJAVA_INSTANCE_DIR, name)
    os.makedirs(instancedir, exist_ok=True)
    os.makedirs(os.path.join(instancedir, "gameDirectory"), exist_ok=True)
    versionfile = open(os.path.join(instancedir, "version.txt"), "w")
    versionfile.write(version)
    versionfile.close()
    os.makedirs()

def java_launcher():
    global version_array
    while True:
        print("Options:")
        print("1. Install Forge")
        print("2. Install Fabric")
        print("3. Install Vanilla")
        print("4. Server List")
        print("5. Sign In")
        print("6. Regenerate Version Array")
        print("7. Start Version")
        print("8. Instances")
        print("9. Settings")
        print("0. Back")
        choice = input("Enter Option:")
        if choice == "1":
            mcver = select_with_search(version_array)
            install_forge(mcver.split(":")[1])
        elif choice == "2":
            mcver = select_with_search(version_array)
            install_fabric(mcver.split(":")[1])
        elif choice == "3":
            mcver = select_with_search(version_array)
            install_vanilla(mcver.split(":")[1])
        elif choice == "4":
            server_list_java()
        elif choice == "5":
            sign_in_java()
            finalize_sign_in_java()
        elif choice == "6":
            generate_version_array_java()
        elif choice == "7":
            mcver = select_with_search(normalize_java_versions_array(minecraft_launcher_lib.utils.get_installed_versions(INSTALL_DIR_MCJAVA)))
            start_mc_java(mcver.split(":")[1])
        elif choice == "8":
            java_launcher_instances()
        elif choice == "9":
            settings_java()
        elif choice == "0":
            main()
            break

def settings_java():
    while True:
        print("Settings")
        print("0. Back")
        print(f"1. Toggle Demo Mode {settings['demo']}")
        print(f"2. Change Memory Allocation {settings['memoryallocation']} MB")
        print(f"3. Toggle log4j Config File {settings['enablelog4jconfig']}")
        print(f"4. Toggle Multiplayer {settings['enableMultiplayer']}")
        print(f"5. Toggle Chat {settings['enableChat']}")
        choice = input("Enter Option:")
        if choice == "0":
            break
        elif choice == "1":
            settings["demo"] = not settings["demo"]
            print(f"Demo Mode: {settings['demo']}")
            save_settings_java()
        elif choice == "2":
            settings["memoryallocation"] = int(input("Enter Memory Allocated in MB: "))
            print(f"Memory Allocated: {settings['memoryallocation']} MB")
            save_settings_java()
        elif choice == "3":
            settings["enablelog4jconfig"] = not settings["enablelog4jconfig"]
            print(f"Log4j Config Enabled: {settings['enablelog4jconfig']}")
            save_settings_java()
        elif choice == "4":
            settings["enableMultiplayer"] = not settings["enableMultiplayer"]
            print(f"Multiplayer Enabled: {settings['enableMultiplayer']}")
            save_settings_java()
        elif choice == "5":
            settings["enableChat"] = not settings["enableChat"]
            print(f"Chat Enabled: {settings['enableChat']}")
            save_settings_java()

def finalize_sign_in_java():
    global signintypejava, usernamejava
    if signintypejava != "1":
        print(f"Saving login data...")
        os.makedirs(os.path.join(DATA_DIR, "java"), exist_ok=True)
        loginfile = open(os.path.join(DATA_DIR, "java", "login.json"), "w")
        logindata = {
            "username": usernamejava,
            "signintype": signintypejava
        }
        loginfile.write(json.dumps(logindata))
        loginfile.close()
    else:
        print("Failed to save login data. Unsupported login for saving login data. login again when starting launcher.")

def sign_in_java():
    global signintypejava, login_url, state, code_verifier, auth_code, login_data, usernamejava
    print("Sign In Options")
    print("1. Microsoft (You will have to resign in every time you start the launcher)")
    print("2. Cracked")
    print("3. Demo")
    signintypejava = input("Enter Sign In Type number: ")
    if signintypejava == "1":
        print("Microsoft Sign In")
        if not ENABLE_MICROSOFT_LOGIN:
            print("ERROR: Microsoft Login is disabled in the config. please enable it to use this feature.")
            print("Make sure to add your apps CLIENT_ID and REDIRECT_URL in the config.")
            return
        # Login
        login_url, state, code_verifier = minecraft_launcher_lib.microsoft_account.get_secure_login_data(CLIENT_ID, REDIRECT_URL)
        print(f"Please open {login_url} in your browser and copy the url you are redirected into the prompt below.")
        code_url = input()

        # Get the code from the url
        try:
            auth_code = minecraft_launcher_lib.microsoft_account.parse_auth_code_url(code_url, state)
        except AssertionError:
            print("States do not match!")
        except KeyError:
            print("Url not valid")

        # Get the login data
        login_data = minecraft_launcher_lib.microsoft_account.complete_login(CLIENT_ID, None, REDIRECT_URL, auth_code, code_verifier)
    elif signintypejava == "2":
        if not ENABLE_CRACKED_LOGIN:
            print("ERROR: Cracked Login is disabled in the config. please enable it to use this feature.")
            return
        print("Cracked Sign In")
        usernamejava = input("Enter Username: ")
        print("Success")

def java_launcher_forge():
    global version_array
    while True:
        print("Options:")
        print("1. Install Forge Version")
        print("2. Play Forge Version")
        print("3. Back")
        choice = input("Enter Option:")
        if choice == "1":
            mcver = select_with_search(version_array)
            install_forge(mcver.split(":")[1])
        elif choice == "2":
            mcver = select_with_search(version_array)
            start_forge(mcver.split(":")[1])
        elif choice == "3":
            break

def install_forge(mcver):
    print("Installing Forge", mcver)
    forge_version = minecraft_launcher_lib.forge.find_forge_version(mcver)
    minecraft_launcher_lib.forge.install_forge_version(forge_version, INSTALL_DIR_MCJAVA, callback=callback, java=JDK_EXE_PATH)
    print("Forge Installed for", mcver)

def start_forge(mcver):
    print("Starting Forge", mcver)
    install_forge(mcver)
    options = generate_options_java()
    minecraft_launcher_lib.launcher.run_minecraft(version=minecraft_launcher_lib.forge.find_forge_version(mcver), run_dir=INSTALL_DIR_MCJAVA, options=options)

def java_launcher_vanilla():
    global version_array
    while True:
        print("Options:")
        print("1. Install Vanilla Version")
        print("2. Play Vanilla Version")
        print("3. Back")
        choice = input("Enter Option:")
        if choice == "1":
            mcver = select_with_search(version_array)
            install_forge(mcver.split(":")[1])
        elif choice == "2":
            mcver = select_with_search(version_array)
            start_forge(mcver.split(":")[1])
        elif choice == "3":
            break

def install_vanilla(mcver):
    print("Installing Vanilla", mcver)
    minecraft_launcher_lib.install.install_minecraft_version(mcver, INSTALL_DIR_MCJAVA, callback=callback)
    print("Vanilla Installed for", mcver)

def start_mc_java(mcver):
    print("Starting Minecraft", mcver)
    options = generate_options_java()
    command =  minecraft_launcher_lib.command.get_minecraft_command(mcver, os.path.abspath(INSTALL_DIR_MCJAVA), options)
    print(command)
    subprocess.run(command)


def java_launcher_fabric():
    global version_array
    while True:
        print("Options:")
        print("1. Install Fabric Version")
        print("2. Play Fabric Version (No auto install if not installed)")
        print("3. Back")
        choice = input("Enter Option:")
        if choice == "1":
            mcver = select_with_search(version_array)
            install_fabric(mcver.split(":")[1])
        elif choice == "2":
            print(minecraft_launcher_lib.utils.get_installed_versions(INSTALL_DIR_MCJAVA))
            mcver = select_with_search(minecraft_launcher_lib.utils.get_installed_versions(INSTALL_DIR_MCJAVA))
            start_fabric(mcver.split(":")[1])
        elif choice == "3":
            break

def install_fabric(mcver):
    print("Installing Fabric", mcver)
    minecraft_launcher_lib.fabric.install_fabric(mcver, INSTALL_DIR_MCJAVA, callback=callback, java=JDK_EXE_PATH)
    print("Forge Installed for", mcver)

def start_fabric(mcver):
    print("Starting Fabric", mcver)
    options = generate_options_java()
    minecraft_launcher_lib.launcher.run_minecraft(version=mcver, run_dir=INSTALL_DIR_MCJAVA, options=options)

def generate_options_java(settingoverride=None):
    global settings
    if settingoverride == None:
        settingoverride = settings
    if signintypejava == "1":
        options = {
            "username": login_data["name"],
            "uuid": login_data["id"],
            "token": login_data["access_token"]
        }
    elif signintypejava == "2":
        options = {
            "username": usernamejava,
        }
    else:
        print("User not signed in or sign in invalid. using placeholder.")
        options = {
            "username": MCJAVA_PLACEHOLDERS["username"],
        }
    options["jvmArguments"] = []
    if settingoverride["demo"]:
        options["demo"] = True
    if settingoverride["memoryallocation"] != -1:
        options["jvmArguments"].append("-Xmx" + str(settingoverride["memoryallocation"]) + "M")
        options["jvmArguments"].append("-Xms" + str(settingoverride["memoryallocation"]) + "M")
    options["executablePath"] = os.path.abspath(JDK_EXE_PATH)
    options["gameDirectory"] = os.path.abspath(GAME_DIR_MCJAVA)
    options["launcherName"] = "SDMCLauncher"
    options["enableLoggingConfig"] = settingoverride["enablelog4jconfig"]
    options["disableMultiplayer"] = not settingoverride["enableMultiplayer"]
    options["disableChat"] = not settingoverride["enableChat"]
    return options

def add_server_java():
    srvfile = open(os.path.join(DATA_DIR, "java", "servers.txt"), "a")
    srvfile.write("\n" + input("Enter Server IP:"))
    srvfile.close()

def remove_server_java():
    srvfile = open(os.path.join(DATA_DIR, "java", "servers.txt"), "r")
    servers = srvfile.read().split("\n")
    srvfile.close()
    for i, server in enumerate(servers):
        print(f"{i + 1}. {server}")
    choice = int(input("Enter Server Number to Remove:"))
    servers.pop(choice - 1)
    srvfile = open(os.path.join(DATA_DIR, "java", "servers.txt"), "w")
    srvfile.write("\n".join(servers))
    srvfile.close()

def server_list_java():
    while True:
        print("Options:")
        print("1. Add Server")
        print("2. Remove Server")
        print("3. List Servers")
        print("4. Back")
        choice = input("Enter Option:")
        if choice == "1":
            add_server_java()
        elif choice == "2":
            remove_server_java()
        elif choice == "3":
            srvfile = open(os.path.join(DATA_DIR, "java", "servers.txt"), "r")
            servers = srvfile.read().split("\n")
            srvfile.close()
            for server in servers:
                if server != "":
                    mcsrv = mcstatus.JavaServer.lookup(server)
                    try:
                        try:
                            pingval = mcsrv.ping()
                        except Exception as err:
                            print(f"{server} -  Error: {err}")
                            pingval = mcsrv.status().latency
                        print(f"{server} - {pingval}ms")
                    except Exception as e:
                        print(f"{server} -  Error: {e}")
        elif choice == "4":
            break

print("Checking for Built-in JDK...")
if not os.path.exists(JDK_INSTALL_DIR):
    print("Built-in JDK not found. Installing JDK...")
    install_jdk()
    print("JDK Installed. Starting Launcher...")

print("Starting launcher...")
main()